(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["walk-through-walk-through-module"],{

/***/ "./src/app/walk-through/walk-through.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/walk-through/walk-through.module.ts ***!
  \*****************************************************/
/*! exports provided: WalkThroughPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WalkThroughPageModule", function() { return WalkThroughPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _walk_through_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./walk-through.page */ "./src/app/walk-through/walk-through.page.ts");







var routes = [
    {
        path: '',
        component: _walk_through_page__WEBPACK_IMPORTED_MODULE_6__["WalkThroughPage"]
    }
];
var WalkThroughPageModule = /** @class */ (function () {
    function WalkThroughPageModule() {
    }
    WalkThroughPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_walk_through_page__WEBPACK_IMPORTED_MODULE_6__["WalkThroughPage"]]
        })
    ], WalkThroughPageModule);
    return WalkThroughPageModule;
}());



/***/ }),

/***/ "./src/app/walk-through/walk-through.page.html":
/*!*****************************************************!*\
  !*** ./src/app/walk-through/walk-through.page.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n\n<ion-content>\n\n    <ion-grid>\n        <ion-row class=\"customRowDesign\">\n          <ion-col>\n            <div class=\"wrapper\">\n              <div class=\"pie spinner\"></div>\n              <div class=\"pie filler\"></div>\n              <div class=\"mask\"></div>\n            </div>\n\n          </ion-col>\n\n        </ion-row>\n\n        <p id=\"demo\" class=\"countdown_timer\"></p>\n\n        <ion-row class=\"customTimer\">\n\n          <ion-col>\n\n        <h3 class=\"continue_text\" (click)=\"continue_()\">Continue</h3>\n            </ion-col>\n        </ion-row>\n\n        </ion-grid>\n\n        <!-- extra packages -->\n        <!-- npm app version\n        app cordova version\n        cordova fb login\n        npm fb\n        ng4 timer -->\n\n</ion-content>\n\n\n<ion-footer>\n  <ion-toolbar class=\"footer\">\n \n    <img src=\"../../assets/fb_icon.png\" class=\"icon_\" alt=\"social_media_icon\">\n    <img src=\"../../assets/google_icon.png\" class=\"icon_\" alt=\"social_media_icon\">\n \n    <img src=\"../../assets/linkedin_icon.png\" class=\"icon_\" alt=\"social_media_icon\">\n \n    <img src=\"../../assets/twitter_icon.png\" class=\"icon_\" alt=\"social_media_icon\">\n \n  </ion-toolbar>\n</ion-footer>\n\n"

/***/ }),

/***/ "./src/app/walk-through/walk-through.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/walk-through/walk-through.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "img.start-png {\n  height: 118px;\n  padding: -1px; }\n\np#demo {\n  text-align: center;\n  font-family: Gotham;\n  font-size: 30px; }\n\nh3.continue_text {\n  margin-top: 30px; }\n\nimg.icon_ {\n  height: 60px;\n  margin: 10px; }\n\n.footer {\n  text-align: center; }\n\nh3.continue_text {\n  font-family: Gotham;\n  color: #006aff;\n  text-align: center;\n  font-weight: bold; }\n\n.wrapper {\n  position: relative;\n  margin: 40px auto;\n  background: white; }\n\n.wrapper,\n.wrapper * {\n  box-sizing: border-box; }\n\n.wrapper {\n  width: 250px;\n  height: 250px; }\n\n.wrapper .pie {\n  width: 50%;\n  height: 100%;\n  transform-origin: 100% 50%;\n  position: absolute;\n  background: #08C;\n  border: 5px solid rgba(0, 0, 0, 0.5); }\n\n.wrapper .spinner {\n  border-radius: 100% 0 0 100% / 50% 0 0 50%;\n  z-index: 200;\n  border-right: none;\n  -webkit-animation: rota 10s linear infinite;\n          animation: rota 10s linear infinite; }\n\n.wrapper:hover .spinner,\n.wrapper:hover .filler,\n.wrapper:hover .mask {\n  -webkit-animation-play-state: running;\n          animation-play-state: running; }\n\n.wrapper .filler {\n  border-radius: 0 100% 100% 0 / 0 50% 50% 0;\n  left: 50%;\n  opacity: 0;\n  z-index: 100;\n  animation: opa 10s steps(1, end) infinite reverse;\n  border-left: none; }\n\n.wrapper .mask {\n  width: 50%;\n  height: 100%;\n  position: absolute;\n  background: inherit;\n  opacity: 1;\n  z-index: 300;\n  -webkit-animation: opa 10s steps(1, end) infinite;\n          animation: opa 10s steps(1, end) infinite; }\n\n@-webkit-keyframes rota {\n  0% {\n    transform: rotate(0deg); }\n  100% {\n    transform: rotate(360deg); } }\n\n@keyframes rota {\n  0% {\n    transform: rotate(0deg); }\n  100% {\n    transform: rotate(360deg); } }\n\n@-webkit-keyframes opa {\n  0% {\n    opacity: 1; }\n  50%,\n  100% {\n    opacity: 0; } }\n\n@keyframes opa {\n  0% {\n    opacity: 1; }\n  50%,\n  100% {\n    opacity: 0; } }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zaHViYW12ZXJtYS9EZXNrdG9wL2t5Y19hcHAvbGVydXRocy9zcmMvYXBwL3dhbGstdGhyb3VnaC93YWxrLXRocm91Z2gucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBYTtFQUNiLGFBQWEsRUFBQTs7QUFLakI7RUFDSSxrQkFBa0I7RUFDbEIsbUJBQW1CO0VBQ25CLGVBQWUsRUFBQTs7QUFHbkI7RUFDSSxnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxZQUFZO0VBQ1osWUFBWSxFQUFBOztBQUdoQjtFQUNJLGtCQUFrQixFQUFBOztBQUl0QjtFQUNJLG1CQUFtQjtFQUNuQixjQUFjO0VBQ2Qsa0JBQWtCO0VBQ2xCLGlCQUFpQixFQUFBOztBQUdyQjtFQUNJLGtCQUFrQjtFQUNsQixpQkFBaUI7RUFDakIsaUJBQWlCLEVBQUE7O0FBR25COztFQUlFLHNCQUFzQixFQUFBOztBQUd4QjtFQUNFLFlBQVk7RUFDWixhQUFhLEVBQUE7O0FBR2Y7RUFDRSxVQUFVO0VBQ1YsWUFBWTtFQUNaLDBCQUEwQjtFQUMxQixrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLG9DQUFvQyxFQUFBOztBQUd0QztFQUNFLDBDQUEwQztFQUMxQyxZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLDJDQUFtQztVQUFuQyxtQ0FBbUMsRUFBQTs7QUFHckM7OztFQUdFLHFDQUE2QjtVQUE3Qiw2QkFBNkIsRUFBQTs7QUFHL0I7RUFDRSwwQ0FBMEM7RUFDMUMsU0FBUztFQUNULFVBQVU7RUFDVixZQUFZO0VBQ1osaURBQWlEO0VBQ2pELGlCQUFpQixFQUFBOztBQUtuQjtFQUNFLFVBQVU7RUFDVixZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLG1CQUFtQjtFQUNuQixVQUFVO0VBQ1YsWUFBWTtFQUNaLGlEQUF5QztVQUF6Qyx5Q0FBeUMsRUFBQTs7QUFHM0M7RUFDRTtJQUNFLHVCQUF1QixFQUFBO0VBR3pCO0lBQ0UseUJBQXlCLEVBQUEsRUFBQTs7QUFON0I7RUFDRTtJQUNFLHVCQUF1QixFQUFBO0VBR3pCO0lBQ0UseUJBQXlCLEVBQUEsRUFBQTs7QUFJN0I7RUFDRTtJQUNFLFVBQVUsRUFBQTtFQUdaOztJQUVFLFVBQVUsRUFBQSxFQUFBOztBQVBkO0VBQ0U7SUFDRSxVQUFVLEVBQUE7RUFHWjs7SUFFRSxVQUFVLEVBQUEsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3dhbGstdGhyb3VnaC93YWxrLXRocm91Z2gucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW1nLnN0YXJ0LXBuZyB7XG4gICAgaGVpZ2h0OiAxMThweDtcbiAgICBwYWRkaW5nOiAtMXB4O1xufVxuXG5cblxucCNkZW1vIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1mYW1pbHk6IEdvdGhhbTtcbiAgICBmb250LXNpemU6IDMwcHg7XG59XG5cbmgzLmNvbnRpbnVlX3RleHQge1xuICAgIG1hcmdpbi10b3A6IDMwcHg7XG59XG5cbmltZy5pY29uXyB7XG4gICAgaGVpZ2h0OiA2MHB4O1xuICAgIG1hcmdpbjogMTBweDtcbn1cblxuLmZvb3RlciB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG5cbmgzLmNvbnRpbnVlX3RleHQge1xuICAgIGZvbnQtZmFtaWx5OiBHb3RoYW07XG4gICAgY29sb3I6ICMwMDZhZmY7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4ud3JhcHBlciB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIG1hcmdpbjogNDBweCBhdXRvO1xuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuICB9XG5cbiAgLndyYXBwZXIsXG4gIC53cmFwcGVyICoge1xuICAgIC1tb3otYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICAtd2Via2l0LWJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgfVxuXG4gIC53cmFwcGVyIHtcbiAgICB3aWR0aDogMjUwcHg7XG4gICAgaGVpZ2h0OiAyNTBweDtcbiAgfVxuXG4gIC53cmFwcGVyIC5waWUge1xuICAgIHdpZHRoOiA1MCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIHRyYW5zZm9ybS1vcmlnaW46IDEwMCUgNTAlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBiYWNrZ3JvdW5kOiAjMDhDO1xuICAgIGJvcmRlcjogNXB4IHNvbGlkIHJnYmEoMCwgMCwgMCwgMC41KTtcbiAgfVxuXG4gIC53cmFwcGVyIC5zcGlubmVyIHtcbiAgICBib3JkZXItcmFkaXVzOiAxMDAlIDAgMCAxMDAlIC8gNTAlIDAgMCA1MCU7XG4gICAgei1pbmRleDogMjAwO1xuICAgIGJvcmRlci1yaWdodDogbm9uZTtcbiAgICBhbmltYXRpb246IHJvdGEgMTBzIGxpbmVhciBpbmZpbml0ZTtcbiAgfVxuXG4gIC53cmFwcGVyOmhvdmVyIC5zcGlubmVyLFxuICAud3JhcHBlcjpob3ZlciAuZmlsbGVyLFxuICAud3JhcHBlcjpob3ZlciAubWFzayB7XG4gICAgYW5pbWF0aW9uLXBsYXktc3RhdGU6IHJ1bm5pbmc7XG4gIH1cblxuICAud3JhcHBlciAuZmlsbGVyIHtcbiAgICBib3JkZXItcmFkaXVzOiAwIDEwMCUgMTAwJSAwIC8gMCA1MCUgNTAlIDA7XG4gICAgbGVmdDogNTAlO1xuICAgIG9wYWNpdHk6IDA7XG4gICAgei1pbmRleDogMTAwO1xuICAgIGFuaW1hdGlvbjogb3BhIDEwcyBzdGVwcygxLCBlbmQpIGluZmluaXRlIHJldmVyc2U7XG4gICAgYm9yZGVyLWxlZnQ6IG5vbmU7XG4gIH1cblxuICBcblxuICAud3JhcHBlciAubWFzayB7XG4gICAgd2lkdGg6IDUwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGJhY2tncm91bmQ6IGluaGVyaXQ7XG4gICAgb3BhY2l0eTogMTtcbiAgICB6LWluZGV4OiAzMDA7XG4gICAgYW5pbWF0aW9uOiBvcGEgMTBzIHN0ZXBzKDEsIGVuZCkgaW5maW5pdGU7XG4gIH1cblxuICBAa2V5ZnJhbWVzIHJvdGEge1xuICAgIDAlIHtcbiAgICAgIHRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xuICAgIH1cblxuICAgIDEwMCUge1xuICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMzYwZGVnKTtcbiAgICB9XG4gIH1cblxuICBAa2V5ZnJhbWVzIG9wYSB7XG4gICAgMCUge1xuICAgICAgb3BhY2l0eTogMTtcbiAgICB9XG5cbiAgICA1MCUsXG4gICAgMTAwJSB7XG4gICAgICBvcGFjaXR5OiAwO1xuICAgIH1cbiAgfSJdfQ== */"

/***/ }),

/***/ "./src/app/walk-through/walk-through.page.ts":
/*!***************************************************!*\
  !*** ./src/app/walk-through/walk-through.page.ts ***!
  \***************************************************/
/*! exports provided: WalkThroughPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WalkThroughPage", function() { return WalkThroughPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var WalkThroughPage = /** @class */ (function () {
    function WalkThroughPage(router) {
        this.router = router;
        if (localStorage.getItem('LoggedInUser_data') != null) {
            this.router.navigate(['MyTab']);
        }
        if (localStorage.getItem('LoggedInUser_data') === null) {
            console.log('done');
        }
        this.countdown();
    }
    WalkThroughPage.prototype.countdown = function () {
        var countDownDate = new Date("Jul 31, 2019 14:50:25").getTime();
        // Update the count down every 1 second
        var x = setInterval(function () {
            // Get todays date and time
            var now = new Date().getTime();
            // Find the distance between now and the count down date
            var distance = countDownDate - now;
            // Time calculations for days, hours, minutes and seconds
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);
            // console.log(now, "now", "countDownDate", countDownDate, "distance", distance, "days", days);
            // Output the result in an element with id="demo"
            document.getElementById("demo").innerHTML = days + "d " + hours + "h "
                + minutes + "m " + seconds + "s ";
            // If the count down is over, write some text 
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("demo").innerHTML = "EXPIRED";
            }
        }, 1000);
    };
    WalkThroughPage.prototype.ngOnInit = function () {
    };
    WalkThroughPage.prototype.continue_ = function () {
        this.router.navigate(['LandingPage']);
    };
    WalkThroughPage.prototype.start = function () {
        this.router.navigate(['register']);
    };
    WalkThroughPage.prototype.login = function () {
        this.router.navigate(['login']);
    };
    WalkThroughPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-walk-through',
            template: __webpack_require__(/*! ./walk-through.page.html */ "./src/app/walk-through/walk-through.page.html"),
            styles: [__webpack_require__(/*! ./walk-through.page.scss */ "./src/app/walk-through/walk-through.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], WalkThroughPage);
    return WalkThroughPage;
}());



/***/ })

}]);
//# sourceMappingURL=walk-through-walk-through-module.js.map