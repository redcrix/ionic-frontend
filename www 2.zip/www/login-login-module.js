(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "./src/app/login/login.module.ts":
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");







var routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]
    }
];
var LoginPageModule = /** @class */ (function () {
    function LoginPageModule() {
    }
    LoginPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
        })
    ], LoginPageModule);
    return LoginPageModule;
}());



/***/ }),

/***/ "./src/app/login/login.page.html":
/*!***************************************!*\
  !*** ./src/app/login/login.page.html ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <ion-header>\n  <ion-toolbar>\n    <ion-title>login</ion-title>\n  </ion-toolbar>\n</ion-header> -->\n\n<ion-content>\n\n    <ion-row class=\"login-intro\">\n        <ion-col  >\n       \n          <img src=\"../../assets/start.png\" alt=\"start_application\" class=\"start-png\">\n        </ion-col>\n\n    </ion-row>\n\n\n    <div class=\"inputBox\">\n        <form [formGroup]=\"loginForm\" >\n      <div class=\"input-sign\">\n          <ion-input class=\"login-input\" formControlName=\"email\"  type=\"text\" placeholder=\"Email\"></ion-input>\n        </div>\n\n        <div class=\"input-sign\">\n            <ion-input class=\"login-input\" formControlName=\"pass\"  type=\"text\" placeholder=\"Password\"></ion-input>\n          </div>\n\n        </form>\n    </div>\n\n    <ion-button expand=\"full\"   [disabled]=\"!loginForm.valid\"  class=\"login-btn\" (click)=\"Login()\"><ion-icon name=\"done-all\"></ion-icon> LOGIN</ion-button >\n  \n\n\n    <ion-row class=\"customRowDesign\">\n        <ion-col (click)=\"start()\" >\n            <p class=\"sub_title\">\n             Start with your application.\n              </p>\n          <img src=\"../../assets/start.png\" alt=\"start_application\" class=\"start-png\">\n        </ion-col>\n\n    </ion-row>\n\n\n   \n<button (click)=\"doFbLogin()\">fb</button>\n\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/login/login.page.scss":
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "img.start-png {\n  height: 118px;\n  padding: -1px; }\n\n.customRowDesign {\n  text-align: center !important;\n  border: 10px solid #383a3e !important;\n  margin: 10px; }\n\nimg.start-png {\n  margin-left: auto;\n  margin-right: auto;\n  display: block; }\n\n.inputBox {\n  padding: 20px; }\n\nion-row.login-intro.ios.hydrated {\n  margin-top: 50px;\n  margin-bottom: 50px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zaHViYW12ZXJtYS9EZXNrdG9wL2t5Y19hcHAvbGVydXRocy9zcmMvYXBwL2xvZ2luL2xvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQWE7RUFDYixhQUFhLEVBQUE7O0FBS2pCO0VBQ0ksNkJBQTZCO0VBQzdCLHFDQUFxQztFQUNyQyxZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksaUJBQWlCO0VBQ2pCLGtCQUFrQjtFQUNsQixjQUFjLEVBQUE7O0FBR2xCO0VBQ0ksYUFBYSxFQUFBOztBQUdqQjtFQUNJLGdCQUFnQjtFQUNoQixtQkFBbUIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2xvZ2luL2xvZ2luLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImltZy5zdGFydC1wbmcge1xuICAgIGhlaWdodDogMTE4cHg7XG4gICAgcGFkZGluZzogLTFweDtcbn1cblxuXG5cbi5jdXN0b21Sb3dEZXNpZ24ge1xuICAgIHRleHQtYWxpZ246IGNlbnRlciAhaW1wb3J0YW50O1xuICAgIGJvcmRlcjogMTBweCBzb2xpZCAjMzgzYTNlICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luOiAxMHB4O1xufVxuXG5pbWcuc3RhcnQtcG5nIHtcbiAgICBtYXJnaW4tbGVmdDogYXV0bztcbiAgICBtYXJnaW4tcmlnaHQ6IGF1dG87XG4gICAgZGlzcGxheTogYmxvY2s7XG59XG5cbi5pbnB1dEJveCB7XG4gICAgcGFkZGluZzogMjBweDtcbn1cblxuaW9uLXJvdy5sb2dpbi1pbnRyby5pb3MuaHlkcmF0ZWQge1xuICAgIG1hcmdpbi10b3A6IDUwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogNTBweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/login/login.page.ts":
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/facebook/ngx */ "./node_modules/@ionic-native/facebook/ngx/index.js");








var LoginPage = /** @class */ (function () {
    function LoginPage(fb, api, loadingController, formBuilder, router, toastController, alertController) {
        this.fb = fb;
        this.api = api;
        this.loadingController = loadingController;
        this.formBuilder = formBuilder;
        this.router = router;
        this.toastController = toastController;
        this.alertController = alertController;
        this.FB_APP_ID = 330683611150903;
        this.submitted = false;
        this.loggedIn = false;
        this.loginForm = this.formBuilder.group({
            email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email]],
            pass: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(2)]],
        });
    }
    LoginPage.prototype.ngOnInit = function () {
        if (localStorage.getItem('LoggedInUser_data') != null) {
            this.router.navigate(['MyTab']);
        }
        if (localStorage.getItem('LoggedInUser_data') === null) {
            console.log('done');
        }
    };
    LoginPage.prototype.doFbLogin = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading, permissions;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingController.create({
                            message: 'Please wait...'
                        })];
                    case 1:
                        loading = _a.sent();
                        this.presentLoading(loading);
                        permissions = ["public_profile", "email"];
                        this.fb.login(permissions)
                            .then(function (response) {
                            var userId = response.authResponse.userID;
                            //Getting name and gender properties
                            _this.fb.api("/me?fields=name,email", permissions)
                                .then(function (user) {
                                user.picture = "https://graph.facebook.com/" + userId + "/picture?type=large";
                                //now we have the users info, let's save it in the NativeStorage
                                // this.nativeStorage.setItem('facebook_user',
                                // {
                                // 	name: user.name,
                                // 	email: user.email,
                                // 	picture: user.picture
                                // })
                                // .then(() =>{
                                // 	this.router.navigate(["/user"]);
                                // 	loading.dismiss();
                                // }, error =>{
                                // 	console.log(error);
                                // 	loading.dismiss();
                                // })
                                console.log('USER DETAILS == ' + user);
                            });
                        }, function (error) {
                            console.log(error);
                            loading.dismiss();
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.presentLoading = function (loading) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, loading.present()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    LoginPage.prototype.Login = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingController.create()];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        return [4 /*yield*/, this.api.LoginApi(this.loginForm.value)
                                .subscribe(function (res) {
                                console.log(res);
                                console.log(res);
                                _this.submitted = true;
                                var save_login_within_app = {
                                    name: JSON.stringify(res.name),
                                    id: JSON.stringify(res.id),
                                    auth_token: JSON.stringify(res.auth_token),
                                    type: JSON.stringify(res.type),
                                    email: _this.loginForm.value.email
                                };
                                if (res.status === 0) {
                                    loading.dismiss();
                                }
                                else if (res.status === 1) {
                                    _this.loggedIn = true;
                                    localStorage.removeItem('LoggedInUser_data');
                                    localStorage.setItem('LoggedInUser_data', JSON.stringify(save_login_within_app));
                                    loading.dismiss();
                                    _this.router.navigate(['home']);
                                }
                            }, function (err) {
                                console.log(err);
                                loading.dismiss();
                            })];
                    case 3:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.start = function () {
        this.router.navigate(['register']);
    };
    LoginPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.page.html */ "./src/app/login/login.page.html"),
            styles: [__webpack_require__(/*! ./login.page.scss */ "./src/app/login/login.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_6__["Facebook"], _api_service__WEBPACK_IMPORTED_MODULE_4__["RestApiService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]])
    ], LoginPage);
    return LoginPage;
}());



/***/ })

}]);
//# sourceMappingURL=login-login-module.js.map