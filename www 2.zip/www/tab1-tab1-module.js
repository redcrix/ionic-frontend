(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab1-tab1-module"],{

/***/ "./src/app/tab1/tab1.module.ts":
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.module.ts ***!
  \*************************************/
/*! exports provided: Tab1PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1PageModule", function() { return Tab1PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab1.page */ "./src/app/tab1/tab1.page.ts");







var Tab1PageModule = /** @class */ (function () {
    function Tab1PageModule() {
    }
    Tab1PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
            imports: [
                _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _tab1_page__WEBPACK_IMPORTED_MODULE_6__["Tab1Page"] }])
            ],
            declarations: [_tab1_page__WEBPACK_IMPORTED_MODULE_6__["Tab1Page"]]
        })
    ], Tab1PageModule);
    return Tab1PageModule;
}());



/***/ }),

/***/ "./src/app/tab1/tab1.page.html":
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n\n<ion-content>\n  <ion-card class=\"welcome-card\">\n    <img src=\"/assets/shapes.svg\" alt=\"\" />\n    <ion-card-header>\n      <ion-card-subtitle>Get Started</ion-card-subtitle>\n      <ion-card-title>Welcome to Ahrvo DEXX Kyc App</ion-card-title>\n    </ion-card-header>\n    <ion-card-content>\n      <p>   We Provide Technology Consulting through Process Design & Implementation, Workflow Optimization, & Automation.</p>\n    </ion-card-content>\n  </ion-card>\n\n\n  <ion-row  class=\"startRow\" (click)=\"StartKyc_()\">\n    <ion-col  >\n        <p class=\"sub_title\">\n         Start with your Kyc\n          </p>\n      <!-- <img  src=\"../../assets/start.png\" alt=\"start_application\" class=\"start-png\"> -->\n    </ion-col>\n</ion-row>\n\n<ion-row  class=\"Count_row\" >\n  <ion-col  >\n    <p class=\"timer_text\">Ea ius adhuc dolore minimum. Rebum dignissim</p>\n    <p class=\"timer_text\">ਨਹੀ ! ਬਜਾਇ ਕਿ ਏਹੁ ਵਰਤਮਾਨ ਪੰਜਾਬੀ ਦੇ ਸ਼ਬਦਾਂ ਦੀ ਹੇਰ-ਫ਼ੇਰ ਹੈ </p>\n    \n    <p id=\"demo\" class=\"countdown_timer\"></p>\n  </ion-col>\n</ion-row>\n\n<ion-row  class=\"ImgBanner\">\n    <ion-col  >\n      <img  src=\"../../assets/verification_system.png\" alt=\"verification\" class=\"system-png\">\n    </ion-col>\n</ion-row>\n\n\n\n\n\n\n  <!-- <ion-list lines=\"none\">\n    <ion-list-header>\n      <ion-label>Resources</ion-label>\n    </ion-list-header>\n    <ion-item href=\"https://ionicframework.com/docs/\">\n      <ion-icon slot=\"start\" color=\"medium\" name=\"book\"></ion-icon>\n      <ion-label> Documentation</ion-label>\n    </ion-item>\n    <ion-item href=\"https://ionicframework.com/docs/building/scaffolding\">\n      <ion-icon slot=\"start\" color=\"medium\" name=\"build\"></ion-icon>\n      <ion-label>Scaffold Out Your App</ion-label>\n    </ion-item>\n    <ion-item href=\"https://ionicframework.com/docs/layout/structure\">\n      <ion-icon slot=\"start\" color=\"medium\" name=\"grid\"></ion-icon>\n      <ion-label>Your App Layout</ion-label>\n    </ion-item>\n    <ion-item href=\"https://ionicframework.com/docs/theming/basics\">\n      <ion-icon slot=\"start\" color=\"medium\" name=\"color-fill\"></ion-icon>\n      <ion-label>Theme Your App</ion-label>\n    </ion-item>\n \n  </ion-list> -->\n\n    <ion-grid>\n      <ion-row class=\"row_ico_icons\">\n        <ion-col col-lg-3 col-sm-6 col-6>\n          <div class=\"rating-item-ahrvo mb-3\">\n            <a href=\"https://icomarks.com/ico/ahrvodeex\" target=\"_blank\" rel=\"nofollow\" title=\"AhrvoDEEX ICO\"><img border=\"0\" src=\"https://icomarks.com/widget/a/ahrvodeex/square.svg\" class=\"img_ico\"   alt=\"AhrvoDEEX ICO Rating\"></a>\n        </div>\n        </ion-col>\n        <ion-col col-lg-3 col-sm-6 col-6>\n          <div class=\"rating-item-ahrvo\">\n            <a href=\"https://icobench.com/ico/ahrvodeex\" target=\"_blank\" rel=\"nofollow\" title=\"AhrvoDEEX on ICObench\"><img border=\"0\" src=\"https://icobench.com/rated/ahrvodeex?shape=square&amp;size=m\"  alt=\"AhrvoDEEX ICO rating\" class=\"img_ico\" ></a>\n        </div>\n        </ion-col>\n        <ion-col col-lg-3 col-sm-6 col-6>\n          <div class=\"rating-item-ahrvo\">\n            <a href=\"https://www.trackico.io/ico/ahrvodeex/\" target=\"_blank\" title=\"AhrvoDEEX on TrackICO\">\n                <img border=\"0\" src=\"https://www.trackico.io/widget/square/ahrvodeex/205.png\" class=\"img_ico\" alt=\"AhrvoDEEX TrackICO rating\">\n            </a>\n        </div>\n        </ion-col>\n        <ion-col col-lg-3 col-sm-6 col-6>\n          <div class=\"rating-item-ahrvo\">\n            <a href=\"https://icotop.io/project/ahrvodeex\" target=\"_blank\"><img src=\"../../assets/ico.png\" alt=\"\" class=\"img_ico\" ></a>\n        </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n\n \n\n\n\n\n\n  <ion-row>\n\n  <ion-col class=\"CustomLinks\">\n      <div class=\"bg\">\n        <ul class=\"Ul_custom\">\n       \n        <li class=\"link__\" (click)=\"Website()\">\n          Website\n        </li>\n\n        <li class=\"link__\" (click)=\"TermsofUse()\">\n          Terms\n        </li>\n\n        <li class=\"link__\" (click)=\"PrivacyPolicy()\">\n          Policy\n        </li>\n\n        <li class=\"link__\" (click)=\"DataProtectionPolicy()\">\n          Protection\n        </li>\n      </ul>\n      </div>\n    </ion-col>\n\n    <ion-col class=\"CustomLinks\">\n      <div class=\"bg\">\n        <ul class=\"Ul_custom\">\n       \n        <li class=\"link__\" (click)=\"Website()\">\n          Website\n        </li>\n\n        <li class=\"link__\" (click)=\"TermsofUse()\">\n          Terms\n        </li>\n\n        <li class=\"link__\" (click)=\"PrivacyPolicy()\">\n          Policy\n        </li>\n\n        <li class=\"link__\" (click)=\"DataProtectionPolicy()\">\n          Protection\n        </li>\n      </ul>\n      </div>\n    </ion-col>\n\n    <ion-col class=\"CustomLinks\">\n      <div class=\"bg\">\n        <ul class=\"Ul_custom\">\n       \n        <li class=\"link__\" (click)=\"Website()\">\n          Website\n        </li>\n\n        <li class=\"link__\" (click)=\"TermsofUse()\">\n          Terms\n        </li>\n\n        <li class=\"link__\" (click)=\"PrivacyPolicy()\">\n          Policy\n        </li>\n\n        <li class=\"link__\" (click)=\"DataProtectionPolicy()\">\n          Protection\n        </li>\n      </ul>\n      </div>\n    </ion-col>\n\n  </ion-row>\n\n  <ion-row class=\"customFooter\">\n\n\n    <ion-col>\n      <p class=\"About\">Social Links</p>\n      <div class=\"bg\">\n        <div class=\"icons__\">\n          <img (click)=\"followFb()\" src=\"../../assets/fb_icon.png\" class=\"icon_\" alt=\"social_media_icon\">\n          <img (click)=\"followFb()\" src=\"../../assets/google_icon.png\" class=\"icon_\" alt=\"social_media_icon\">\n          <img (click)=\"LinkedIn()\" src=\"../../assets/linkedin_icon.png\" class=\"icon_\" alt=\"social_media_icon\">\n          <img (click)=\"Twitter()\" src=\"../../assets/twitter_icon.png\" class=\"icon_\" alt=\"social_media_icon\">\n          <img (click)=\"Instagram()\" src=\"../../assets/insta_icon.png\" class=\"icon_\" alt=\"social_media_icon\">\n\n        </div>\n      </div>\n    </ion-col>\n\n    <ion-col>\n\n      <p class=\"About\">Meet</p>\n      <div class=\"bg\">\n        <img (click)=\"Zoom()\" src=\"../../assets/zoom_icon.png\" class=\"icon_\" alt=\"social_media_icon\">\n        <img (click)=\"Calendly()\" src=\"../../assets/calendy_icon.png\" class=\"icon_\" alt=\"social_media_icon\">\n        <img (click)=\"Reddit()\" src=\"../../assets/reddit_icon.png\" class=\"icon_\" alt=\"social_media_icon\">\n        <img (click)=\"Telegram()\" src=\"../../assets/telegram_icon.png\" class=\"icon_\" alt=\"social_media_icon\">\n        <img (click)=\"Medium()\" src=\"../../assets/medium_icon.png\" class=\"icon_\" alt=\"social_media_icon\">\n      </div>\n    </ion-col>\n\n  </ion-row>\n\n\n  <ion-item (click)=\"logout()\">\n      <ion-icon slot=\"start\" color=\"medium\" name=\"log-out\" class=\"logout\"></ion-icon>\n      <ion-label>Logout</ion-label>\n    </ion-item>\n\n\n\n\n  <!-- Placeholder –\n  Placeholder –\n  Placeholder –\n  Placeholder –\n  Placeholder – -->\n\n</ion-content>"

/***/ }),

/***/ "./src/app/tab1/tab1.page.scss":
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".welcome-card img {\n  max-height: 35vh;\n  overflow: hidden; }\n\nimg.icon_ {\n  height: 42px;\n  margin: 10px; }\n\nimg.start-png {\n  height: 40px; }\n\n.bg {\n  background: aliceblue;\n  padding: 10px; }\n\nul.Ul_custom {\n  list-style-type: none; }\n\np.About {\n  background: #006aff;\n  padding: 10px;\n  color: white;\n  font-family: Gotham;\n  font-weight: bold;\n  margin-bottom: -1px; }\n\nion-row.ImgBanner.md.hydrated {\n  text-align: center; }\n\nion-row.Count_row.md.hydrated {\n  text-align: center; }\n\nion-col.CustomLinks.md.hydrated {\n  border-top: 1px solid  #006aff; }\n\nli.link__ {\n  margin-bottom: 6px;\n  color: gray;\n  font-family: Gotham;\n  text-decoration: underline; }\n\nli.link__:hover {\n  color: #006aff; }\n\nion-row.startRow.md.hydrated {\n  background: linear-gradient(0deg, #22c1c3 0%, #006aff 100%); }\n\nion-row.startRow.md.hydrated {\n  text-align: center;\n  margin-bottom: 20px;\n  border-top: 1px solid #006aff; }\n\np.sub_title {\n  font-family: Gotham;\n  color: antiquewhite;\n  font-size: 38px; }\n\nimg.img_ico {\n  height: 129px; }\n\nion-row.row_ico_icons.md.hydrated {\n  text-align: center; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zaHViYW12ZXJtYS9EZXNrdG9wL2t5Y19hcHAvbGVydXRocy9zcmMvYXBwL3RhYjEvdGFiMS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQkFBZ0I7RUFDaEIsZ0JBQWdCLEVBQUE7O0FBR2xCO0VBQ0UsWUFBWTtFQUNaLFlBQVksRUFBQTs7QUFJZDtFQUNFLFlBQVksRUFBQTs7QUFHZDtFQUNFLHFCQUFxQjtFQUNyQixhQUFhLEVBQUE7O0FBR2Y7RUFDRSxxQkFBcUIsRUFBQTs7QUFHdkI7RUFDRSxtQkFBbUI7RUFDbkIsYUFBYTtFQUNiLFlBQVk7RUFDWixtQkFBbUI7RUFDbkIsaUJBQWlCO0VBQ2pCLG1CQUFtQixFQUFBOztBQUdyQjtFQUNFLGtCQUFrQixFQUFBOztBQUdwQjtFQUNFLGtCQUFrQixFQUFBOztBQUdwQjtFQUNFLDhCQUE4QixFQUFBOztBQUdoQztFQUNFLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsbUJBQW1CO0VBQ25CLDBCQUEwQixFQUFBOztBQUc1QjtFQUNFLGNBQWMsRUFBQTs7QUFHaEI7RUFDRSwyREFBZ0YsRUFBQTs7QUFHbEY7RUFDRSxrQkFBa0I7RUFDbEIsbUJBQW1CO0VBQ25CLDZCQUE2QixFQUFBOztBQUcvQjtFQUNFLG1CQUFtQjtFQUNuQixtQkFBbUI7RUFDbkIsZUFBZSxFQUFBOztBQUdqQjtFQUNFLGFBQWEsRUFBQTs7QUFHZjtFQUNFLGtCQUFrQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvdGFiMS90YWIxLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi53ZWxjb21lLWNhcmQgaW1nIHtcbiAgbWF4LWhlaWdodDogMzV2aDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuaW1nLmljb25fIHtcbiAgaGVpZ2h0OiA0MnB4O1xuICBtYXJnaW46IDEwcHg7XG59XG5cblxuaW1nLnN0YXJ0LXBuZyB7XG4gIGhlaWdodDogNDBweDtcbn1cblxuLmJnIHtcbiAgYmFja2dyb3VuZDogYWxpY2VibHVlO1xuICBwYWRkaW5nOiAxMHB4O1xufVxuXG51bC5VbF9jdXN0b20ge1xuICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XG59XG5cbnAuQWJvdXQge1xuICBiYWNrZ3JvdW5kOiAjMDA2YWZmO1xuICBwYWRkaW5nOiAxMHB4O1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtZmFtaWx5OiBHb3RoYW07XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBtYXJnaW4tYm90dG9tOiAtMXB4O1xufVxuXG5pb24tcm93LkltZ0Jhbm5lci5tZC5oeWRyYXRlZCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuaW9uLXJvdy5Db3VudF9yb3cubWQuaHlkcmF0ZWQge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbmlvbi1jb2wuQ3VzdG9tTGlua3MubWQuaHlkcmF0ZWQge1xuICBib3JkZXItdG9wOiAxcHggc29saWQgICMwMDZhZmY7XG59XG5cbmxpLmxpbmtfXyB7XG4gIG1hcmdpbi1ib3R0b206IDZweDtcbiAgY29sb3I6IGdyYXk7XG4gIGZvbnQtZmFtaWx5OiBHb3RoYW07XG4gIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xufVxuXG5saS5saW5rX186aG92ZXJ7XG4gIGNvbG9yOiAjMDA2YWZmO1xufVxuXG5pb24tcm93LnN0YXJ0Um93Lm1kLmh5ZHJhdGVkIHtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDBkZWcsIHJnYmEoMzQsMTkzLDE5NSwxKSAwJSwgcmdiYSgwLDEwNiwyNTUsMSkgMTAwJSk7XG59XG5cbmlvbi1yb3cuc3RhcnRSb3cubWQuaHlkcmF0ZWQge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gIGJvcmRlci10b3A6IDFweCBzb2xpZCAjMDA2YWZmO1xufVxuXG5wLnN1Yl90aXRsZSB7XG4gIGZvbnQtZmFtaWx5OiBHb3RoYW07XG4gIGNvbG9yOiBhbnRpcXVld2hpdGU7XG4gIGZvbnQtc2l6ZTogMzhweDtcbn1cblxuaW1nLmltZ19pY28ge1xuICBoZWlnaHQ6IDEyOXB4O1xufVxuXG5pb24tcm93LnJvd19pY29faWNvbnMubWQuaHlkcmF0ZWQge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbiJdfQ== */"

/***/ }),

/***/ "./src/app/tab1/tab1.page.ts":
/*!***********************************!*\
  !*** ./src/app/tab1/tab1.page.ts ***!
  \***********************************/
/*! exports provided: Tab1Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1Page", function() { return Tab1Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/in-app-browser/ngx */ "./node_modules/@ionic-native/in-app-browser/ngx/index.js");




var Tab1Page = /** @class */ (function () {
    function Tab1Page(router, iab) {
        this.router = router;
        this.iab = iab;
        this.countdown();
    }
    Tab1Page.prototype.logout = function () {
        localStorage.removeItem('LoggedInUser_data');
        this.router.navigate(['walk-through']);
    };
    // YouTube – 
    // Google My Business – 
    // Crunchbase – 
    // Bitcoin Talk – 
    Tab1Page.prototype.TermsofUse = function () {
        this.router.navigate(['terms']);
    };
    Tab1Page.prototype.PrivacyPolicy = function () {
        this.router.navigate(['privacy-policy']);
    };
    Tab1Page.prototype.DataProtectionPolicy = function () {
        this.router.navigate(['data-protection']);
    };
    Tab1Page.prototype.Calendly = function () {
        this.iab.create('https://calendly.com/leruths');
    };
    Tab1Page.prototype.Zoom = function () {
        this.iab.create('https://zoom.us/j/9811913253');
    };
    Tab1Page.prototype.followFb = function () {
        this.iab.create('https://www.facebook.com/LeruthsTech');
    };
    Tab1Page.prototype.Website = function () {
        this.iab.create('https://www.leruths.io');
    };
    Tab1Page.prototype.Twitter = function () {
        this.iab.create('https://twitter.com/LeruthsTech');
    };
    Tab1Page.prototype.LinkedIn = function () {
        this.iab.create('https://www.linkedin.com/company/leruthstech');
    };
    Tab1Page.prototype.Instagram = function () {
        this.iab.create('https://www.instagram.com/LeruthsTech');
    };
    Tab1Page.prototype.Reddit = function () {
        this.iab.create('https://www.reddit.com/user/LeruthsTech');
    };
    Tab1Page.prototype.Medium = function () {
        this.iab.create('https://medium.com/@LeruthsTech');
    };
    Tab1Page.prototype.Telegram = function () {
        this.iab.create('https://t.me/LeruthTech');
    };
    Tab1Page.prototype.BitcoinWiki = function () {
        this.iab.create('https://en.bitcoinwiki.org/wiki/LeruthTech');
    };
    Tab1Page.prototype.StartKyc_ = function () {
        this.router.navigate(['register']);
    };
    Tab1Page.prototype.countdown = function () {
        var countDownDate = new Date("Jul 31, 2019 14:50:25").getTime();
        // Update the count down every 1 second
        var x = setInterval(function () {
            // Get todays date and time
            var now = new Date().getTime();
            // Find the distance between now and the count down date
            var distance = countDownDate - now;
            // Time calculations for days, hours, minutes and seconds
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);
            //  console.log(now, "now", "countDownDate", countDownDate, "distance", distance, "days", days);
            // Output the result in an element with id="demo"
            document.getElementById("demo").innerHTML = days + "d " + hours + "h "
                + minutes + "m " + seconds + "s ";
            // If the count down is over, write some text 
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("demo").innerHTML = "EXPIRED";
            }
        }, 1000);
    };
    Tab1Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tab1',
            template: __webpack_require__(/*! ./tab1.page.html */ "./src/app/tab1/tab1.page.html"),
            styles: [__webpack_require__(/*! ./tab1.page.scss */ "./src/app/tab1/tab1.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_3__["InAppBrowser"]])
    ], Tab1Page);
    return Tab1Page;
}());



/***/ })

}]);
//# sourceMappingURL=tab1-tab1-module.js.map