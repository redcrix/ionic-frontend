(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["walk-through-walk-through-module"],{

/***/ "./src/app/walk-through/walk-through.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/walk-through/walk-through.module.ts ***!
  \*****************************************************/
/*! exports provided: WalkThroughPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WalkThroughPageModule", function() { return WalkThroughPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _walk_through_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./walk-through.page */ "./src/app/walk-through/walk-through.page.ts");







var routes = [
    {
        path: '',
        component: _walk_through_page__WEBPACK_IMPORTED_MODULE_6__["WalkThroughPage"]
    }
];
var WalkThroughPageModule = /** @class */ (function () {
    function WalkThroughPageModule() {
    }
    WalkThroughPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_walk_through_page__WEBPACK_IMPORTED_MODULE_6__["WalkThroughPage"]]
        })
    ], WalkThroughPageModule);
    return WalkThroughPageModule;
}());



/***/ }),

/***/ "./src/app/walk-through/walk-through.page.html":
/*!*****************************************************!*\
  !*** ./src/app/walk-through/walk-through.page.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n\n<ion-content>\n\n    <ion-grid>\n        <ion-row class=\"customRowDesign\">\n          <ion-col>\n            <div class=\"wrapper\">\n              <div class=\"pie spinner\"></div>\n              <div class=\"pie filler\"></div>\n              <div class=\"mask\"></div>\n            </div>\n\n          </ion-col>\n\n        </ion-row>\n\n        <p id=\"demo\" class=\"countdown_timer\"></p>\n\n        <ion-row class=\"customTimer\">\n\n          <ion-col>\n\n        <h3 class=\"continue_text\" (click)=\"continue_()\">Continue</h3>\n            </ion-col>\n        </ion-row>\n\n        </ion-grid>\n\n        <!-- extra packages -->\n        <!-- npm app version\n        app cordova version\n        cordova fb login\n        npm fb\n        ng4 timer -->\n\n</ion-content>\n\n\n\n<ion-footer>\n  <ion-toolbar class=\"footer\">\n \n   <img src=\"../../assets/fb_icon.png\" class=\"icon_\" (click)=\"socialFb()\" alt=\"social_media_icon\">\n    <img src=\"../../assets/google_icon.png\" class=\"icon_\" (click)=\"socialGoogle()\"  alt=\"social_media_icon\">\n \n    <img src=\"../../assets/linkedin_icon.png\" class=\"icon_\" alt=\"social_media_icon\">\n \n    <img src=\"../../assets/twitter_icon.png\" class=\"icon_\" alt=\"social_media_icon\">\n \n  </ion-toolbar>\n</ion-footer>\n\n"

/***/ }),

/***/ "./src/app/walk-through/walk-through.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/walk-through/walk-through.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "img.start-png {\n  height: 118px;\n  padding: -1px; }\n\np#demo {\n  text-align: center;\n  font-family: Gotham;\n  font-size: 30px; }\n\nh3.continue_text {\n  margin-top: 30px; }\n\nimg.icon_ {\n  height: 60px;\n  margin: 10px; }\n\n.footer {\n  text-align: center; }\n\nh3.continue_text {\n  font-family: Gotham;\n  color: #006aff;\n  text-align: center;\n  font-weight: bold; }\n\n.wrapper {\n  position: relative;\n  margin: 40px auto;\n  background: white; }\n\n.wrapper,\n.wrapper * {\n  box-sizing: border-box; }\n\n.wrapper {\n  width: 250px;\n  height: 250px; }\n\n.wrapper .pie {\n  width: 50%;\n  height: 100%;\n  transform-origin: 100% 50%;\n  position: absolute;\n  background: #08C;\n  border: 5px solid rgba(0, 0, 0, 0.5); }\n\n.wrapper .spinner {\n  border-radius: 100% 0 0 100% / 50% 0 0 50%;\n  z-index: 200;\n  border-right: none;\n  -webkit-animation: rota 10s linear infinite;\n          animation: rota 10s linear infinite; }\n\n.wrapper:hover .spinner,\n.wrapper:hover .filler,\n.wrapper:hover .mask {\n  -webkit-animation-play-state: running;\n          animation-play-state: running; }\n\n.wrapper .filler {\n  border-radius: 0 100% 100% 0 / 0 50% 50% 0;\n  left: 50%;\n  opacity: 0;\n  z-index: 100;\n  animation: opa 10s steps(1, end) infinite reverse;\n  border-left: none; }\n\n.wrapper .mask {\n  width: 50%;\n  height: 100%;\n  position: absolute;\n  background: inherit;\n  opacity: 1;\n  z-index: 300;\n  -webkit-animation: opa 10s steps(1, end) infinite;\n          animation: opa 10s steps(1, end) infinite; }\n\n@-webkit-keyframes rota {\n  0% {\n    transform: rotate(0deg); }\n  100% {\n    transform: rotate(360deg); } }\n\n@keyframes rota {\n  0% {\n    transform: rotate(0deg); }\n  100% {\n    transform: rotate(360deg); } }\n\n@-webkit-keyframes opa {\n  0% {\n    opacity: 1; }\n  50%,\n  100% {\n    opacity: 0; } }\n\n@keyframes opa {\n  0% {\n    opacity: 1; }\n  50%,\n  100% {\n    opacity: 0; } }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zaHViYW12ZXJtYS9EZXNrdG9wL2t5Y19hcHAvaW9uaWNfZnJvbnRlbmQvaW9uaWMtZnJvbnRlbmQvc3JjL2FwcC93YWxrLXRocm91Z2gvd2Fsay10aHJvdWdoLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQWE7RUFDYixhQUFhLEVBQUE7O0FBS2pCO0VBQ0ksa0JBQWtCO0VBQ2xCLG1CQUFtQjtFQUNuQixlQUFlLEVBQUE7O0FBR25CO0VBQ0ksZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksWUFBWTtFQUNaLFlBQVksRUFBQTs7QUFHaEI7RUFDSSxrQkFBa0IsRUFBQTs7QUFJdEI7RUFDSSxtQkFBbUI7RUFDbkIsY0FBYztFQUNkLGtCQUFrQjtFQUNsQixpQkFBaUIsRUFBQTs7QUFHckI7RUFDSSxrQkFBa0I7RUFDbEIsaUJBQWlCO0VBQ2pCLGlCQUFpQixFQUFBOztBQUduQjs7RUFJRSxzQkFBc0IsRUFBQTs7QUFHeEI7RUFDRSxZQUFZO0VBQ1osYUFBYSxFQUFBOztBQUdmO0VBQ0UsVUFBVTtFQUNWLFlBQVk7RUFDWiwwQkFBMEI7RUFDMUIsa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixvQ0FBb0MsRUFBQTs7QUFHdEM7RUFDRSwwQ0FBMEM7RUFDMUMsWUFBWTtFQUNaLGtCQUFrQjtFQUNsQiwyQ0FBbUM7VUFBbkMsbUNBQW1DLEVBQUE7O0FBR3JDOzs7RUFHRSxxQ0FBNkI7VUFBN0IsNkJBQTZCLEVBQUE7O0FBRy9CO0VBQ0UsMENBQTBDO0VBQzFDLFNBQVM7RUFDVCxVQUFVO0VBQ1YsWUFBWTtFQUNaLGlEQUFpRDtFQUNqRCxpQkFBaUIsRUFBQTs7QUFLbkI7RUFDRSxVQUFVO0VBQ1YsWUFBWTtFQUNaLGtCQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsVUFBVTtFQUNWLFlBQVk7RUFDWixpREFBeUM7VUFBekMseUNBQXlDLEVBQUE7O0FBRzNDO0VBQ0U7SUFDRSx1QkFBdUIsRUFBQTtFQUd6QjtJQUNFLHlCQUF5QixFQUFBLEVBQUE7O0FBTjdCO0VBQ0U7SUFDRSx1QkFBdUIsRUFBQTtFQUd6QjtJQUNFLHlCQUF5QixFQUFBLEVBQUE7O0FBSTdCO0VBQ0U7SUFDRSxVQUFVLEVBQUE7RUFHWjs7SUFFRSxVQUFVLEVBQUEsRUFBQTs7QUFQZDtFQUNFO0lBQ0UsVUFBVSxFQUFBO0VBR1o7O0lBRUUsVUFBVSxFQUFBLEVBQUEiLCJmaWxlIjoic3JjL2FwcC93YWxrLXRocm91Z2gvd2Fsay10aHJvdWdoLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImltZy5zdGFydC1wbmcge1xuICAgIGhlaWdodDogMTE4cHg7XG4gICAgcGFkZGluZzogLTFweDtcbn1cblxuXG5cbnAjZGVtbyB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtZmFtaWx5OiBHb3RoYW07XG4gICAgZm9udC1zaXplOiAzMHB4O1xufVxuXG5oMy5jb250aW51ZV90ZXh0IHtcbiAgICBtYXJnaW4tdG9wOiAzMHB4O1xufVxuXG5pbWcuaWNvbl8ge1xuICAgIGhlaWdodDogNjBweDtcbiAgICBtYXJnaW46IDEwcHg7XG59XG5cbi5mb290ZXIge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuXG5oMy5jb250aW51ZV90ZXh0IHtcbiAgICBmb250LWZhbWlseTogR290aGFtO1xuICAgIGNvbG9yOiAjMDA2YWZmO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLndyYXBwZXIge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICBtYXJnaW46IDQwcHggYXV0bztcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgfVxuXG4gIC53cmFwcGVyLFxuICAud3JhcHBlciAqIHtcbiAgICAtbW96LWJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgLXdlYmtpdC1ib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIH1cblxuICAud3JhcHBlciB7XG4gICAgd2lkdGg6IDI1MHB4O1xuICAgIGhlaWdodDogMjUwcHg7XG4gIH1cblxuICAud3JhcHBlciAucGllIHtcbiAgICB3aWR0aDogNTAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICB0cmFuc2Zvcm0tb3JpZ2luOiAxMDAlIDUwJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgYmFja2dyb3VuZDogIzA4QztcbiAgICBib3JkZXI6IDVweCBzb2xpZCByZ2JhKDAsIDAsIDAsIDAuNSk7XG4gIH1cblxuICAud3JhcHBlciAuc3Bpbm5lciB7XG4gICAgYm9yZGVyLXJhZGl1czogMTAwJSAwIDAgMTAwJSAvIDUwJSAwIDAgNTAlO1xuICAgIHotaW5kZXg6IDIwMDtcbiAgICBib3JkZXItcmlnaHQ6IG5vbmU7XG4gICAgYW5pbWF0aW9uOiByb3RhIDEwcyBsaW5lYXIgaW5maW5pdGU7XG4gIH1cblxuICAud3JhcHBlcjpob3ZlciAuc3Bpbm5lcixcbiAgLndyYXBwZXI6aG92ZXIgLmZpbGxlcixcbiAgLndyYXBwZXI6aG92ZXIgLm1hc2sge1xuICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiBydW5uaW5nO1xuICB9XG5cbiAgLndyYXBwZXIgLmZpbGxlciB7XG4gICAgYm9yZGVyLXJhZGl1czogMCAxMDAlIDEwMCUgMCAvIDAgNTAlIDUwJSAwO1xuICAgIGxlZnQ6IDUwJTtcbiAgICBvcGFjaXR5OiAwO1xuICAgIHotaW5kZXg6IDEwMDtcbiAgICBhbmltYXRpb246IG9wYSAxMHMgc3RlcHMoMSwgZW5kKSBpbmZpbml0ZSByZXZlcnNlO1xuICAgIGJvcmRlci1sZWZ0OiBub25lO1xuICB9XG5cbiAgXG5cbiAgLndyYXBwZXIgLm1hc2sge1xuICAgIHdpZHRoOiA1MCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBiYWNrZ3JvdW5kOiBpbmhlcml0O1xuICAgIG9wYWNpdHk6IDE7XG4gICAgei1pbmRleDogMzAwO1xuICAgIGFuaW1hdGlvbjogb3BhIDEwcyBzdGVwcygxLCBlbmQpIGluZmluaXRlO1xuICB9XG5cbiAgQGtleWZyYW1lcyByb3RhIHtcbiAgICAwJSB7XG4gICAgICB0cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTtcbiAgICB9XG5cbiAgICAxMDAlIHtcbiAgICAgIHRyYW5zZm9ybTogcm90YXRlKDM2MGRlZyk7XG4gICAgfVxuICB9XG5cbiAgQGtleWZyYW1lcyBvcGEge1xuICAgIDAlIHtcbiAgICAgIG9wYWNpdHk6IDE7XG4gICAgfVxuXG4gICAgNTAlLFxuICAgIDEwMCUge1xuICAgICAgb3BhY2l0eTogMDtcbiAgICB9XG4gIH0iXX0= */"

/***/ }),

/***/ "./src/app/walk-through/walk-through.page.ts":
/*!***************************************************!*\
  !*** ./src/app/walk-through/walk-through.page.ts ***!
  \***************************************************/
/*! exports provided: WalkThroughPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WalkThroughPage", function() { return WalkThroughPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");
/* harmony import */ var angular4_social_login__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! angular4-social-login */ "./node_modules/angular4-social-login/angular4-social-login.umd.js");
/* harmony import */ var angular4_social_login__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(angular4_social_login__WEBPACK_IMPORTED_MODULE_5__);








var WalkThroughPage = /** @class */ (function () {
    function WalkThroughPage(api, loadingController, toastController, alertController, router, authService) {
        this.api = api;
        this.loadingController = loadingController;
        this.toastController = toastController;
        this.alertController = alertController;
        this.router = router;
        this.authService = authService;
        if (localStorage.getItem('LoggedInUser_data') != null) {
            this.router.navigate(['MyTab']);
        }
        if (localStorage.getItem('LoggedInUser_data') === null) {
            console.log('done');
        }
        this.countdown();
    }
    WalkThroughPage.prototype.countdown = function () {
        var countDownDate = new Date("Jul 31, 2019 14:50:25").getTime();
        // Update the count down every 1 second
        var x = setInterval(function () {
            // Get todays date and time
            var now = new Date().getTime();
            // Find the distance between now and the count down date
            var distance = countDownDate - now;
            // Time calculations for days, hours, minutes and seconds
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);
            // console.log(now, "now", "countDownDate", countDownDate, "distance", distance, "days", days);
            // Output the result in an element with id="demo"
            document.getElementById("demo").innerHTML = days + "d " + hours + "h "
                + minutes + "m " + seconds + "s ";
            // If the count down is over, write some text 
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("demo").innerHTML = "EXPIRED";
            }
        }, 1000);
    };
    WalkThroughPage.prototype.ngOnInit = function () {
        var _this = this;
        this.authService.authState.subscribe(function (user) {
            console.log('debug 1 ==============' + JSON.stringify(user));
            _this.user = user;
            _this.loggedIn = (user != null);
            if (_this.loggedIn == true)
                _this.router.navigate(['register']);
            else
                _this.router.navigate(['/']);
        });
    };
    WalkThroughPage.prototype.continue_ = function () {
        this.router.navigate(['LandingPage']);
    };
    WalkThroughPage.prototype.start = function () {
        this.router.navigate(['register']);
    };
    WalkThroughPage.prototype.login = function () {
        this.router.navigate(['login']);
    };
    WalkThroughPage.prototype.socialFb = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.authService.signIn(angular4_social_login__WEBPACK_IMPORTED_MODULE_5__["FacebookLoginProvider"].PROVIDER_ID);
                return [2 /*return*/];
            });
        });
    };
    WalkThroughPage.prototype.socialGoogle = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.authService.signIn(angular4_social_login__WEBPACK_IMPORTED_MODULE_5__["GoogleLoginProvider"].PROVIDER_ID);
                return [2 /*return*/];
            });
        });
    };
    WalkThroughPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-walk-through',
            template: __webpack_require__(/*! ./walk-through.page.html */ "./src/app/walk-through/walk-through.page.html"),
            styles: [__webpack_require__(/*! ./walk-through.page.scss */ "./src/app/walk-through/walk-through.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_api_service__WEBPACK_IMPORTED_MODULE_4__["RestApiService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], angular4_social_login__WEBPACK_IMPORTED_MODULE_5__["AuthService"]])
    ], WalkThroughPage);
    return WalkThroughPage;
}());



/***/ })

}]);
//# sourceMappingURL=walk-through-walk-through-module.js.map