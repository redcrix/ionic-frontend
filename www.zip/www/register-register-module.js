(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["register-register-module"],{

/***/ "./src/app/register/register.module.ts":
/*!*********************************************!*\
  !*** ./src/app/register/register.module.ts ***!
  \*********************************************/
/*! exports provided: RegisterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPageModule", function() { return RegisterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./register.page */ "./src/app/register/register.page.ts");







var routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_6__["RegisterPage"]
    }
];
var RegisterPageModule = /** @class */ (function () {
    function RegisterPageModule() {
    }
    RegisterPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_register_page__WEBPACK_IMPORTED_MODULE_6__["RegisterPage"]]
        })
    ], RegisterPageModule);
    return RegisterPageModule;
}());



/***/ }),

/***/ "./src/app/register/register.page.html":
/*!*********************************************!*\
  !*** ./src/app/register/register.page.html ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar class=\"BackGround\">\n\n    <ion-buttons slot=\"start\" (click)=\"Back()\">\n      <ion-icon name=\"arrow-round-back\"></ion-icon>\n    </ion-buttons>\n\n\n    <ion-title >\n      Logo\n    </ion-title>\n\n\n\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content padding>\n\n  <div class=\"register-box\">\n    <div class=\"icon\">\n      KYC FORM\n    </div>\n\n\n    <div class=\"form\">\n      <form [formGroup]=\"registerForm\">\n        <div class=\"input-sign\">\n          <ion-input name=\"first name\" formControlName=\"FirstName\" class=\"redcart-input\" type=\"text\"\n            placeholder=\"First Name\"></ion-input>\n        </div>\n        <div class=\"input-sign\">\n          <ion-input name=\"middle name\" formControlName=\"MiddleName\" class=\"redcart-input\" type=\"text\"\n            placeholder=\"Middle Name (Optional)\"></ion-input>\n        </div>\n        <div class=\"input-sign\">\n          <ion-input name=\"last name\" name=\"first name\" formControlName=\"LastName\" class=\"redcart-input\" type=\"text\"\n            placeholder=\"Last Name\"></ion-input>\n        </div>\n\n        <div class=\"input-sign\">\n          <ion-input name=\"email\" formControlName=\"email\" class=\"redcart-input\" type=\"text\" placeholder=\"Correct Email\">\n          </ion-input>\n        </div>\n\n        <div class=\"input-sign\">\n          <ion-input name=\"password\" formControlName=\"password\" class=\"redcart-input\" type=\"password\"\n            placeholder=\"Choose Password for Login\"></ion-input>\n        </div>\n\n        <ion-item>\n          <ion-datetime class=\"redcart-input\" formControlName=\"DOB\" displayFormat=\"MM DD YY\"\n            placeholder=\"Select Date of Birth\"></ion-datetime>\n        </ion-item>\n\n        <div class=\"input-sign\">\n          <ion-input formControlName=\"Address\" class=\"redcart-input\" type=\"text\" placeholder=\"Address\"></ion-input>\n        </div>\n\n        <div class=\"input-sign\">\n          <ion-input formControlName=\"Nationality\" class=\"redcart-input\" type=\"text\" placeholder=\"Nationality\">\n          </ion-input>\n        </div>\n\n\n\n\n\n\n\n        <div class=\"btn-submit\">\n          <ion-button class=\"registerBtn\" [disabled]=\"!registerForm.valid\" (click)=\"RegisterFun()\">Sign Up</ion-button>\n       </div>\n        <p class=\"incorrect\" *ngIf=\"unMatchedCredentials\">User Already Registered. User Recover Password Option.</p>\n        <p class=\"incorrect\" *ngIf=\"showErro\">Enter Correct Value.</p>\n      </form>\n\n\n    </div>\n\n\n\n  </div>\n\n</ion-content>"

/***/ }),

/***/ "./src/app/register/register.page.scss":
/*!*********************************************!*\
  !*** ./src/app/register/register.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "input.native-input.sc-ion-input-ios {\n  border-bottom: 1px solid lightgray; }\n\n.icon {\n  background: linear-gradient(0deg, #22c1c3 0%, #006aff 100%);\n  padding: 10px;\n  color: white;\n  margin-bottom: 30px; }\n\np.About {\n  background: linear-gradient(0deg, #22c1c3 0%, #006aff 100%);\n  margin-bottom: 1px;\n  padding: 11px;\n  color: white;\n  font-family: Gotham;\n  font-weight: bold; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zaHViYW12ZXJtYS9EZXNrdG9wL2t5Y19hcHAvbGVydXRocy9zcmMvYXBwL3JlZ2lzdGVyL3JlZ2lzdGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtDQUFrQyxFQUFBOztBQUd0QztFQUNJLDJEQUFnRjtFQUNoRixhQUFhO0VBQ2IsWUFBWTtFQUNaLG1CQUFtQixFQUFBOztBQUd2QjtFQUNJLDJEQUFnRjtFQUNoRixrQkFBa0I7RUFDbEIsYUFBYTtFQUNiLFlBQVk7RUFDWixtQkFBbUI7RUFDbkIsaUJBQWlCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9yZWdpc3Rlci9yZWdpc3Rlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpbnB1dC5uYXRpdmUtaW5wdXQuc2MtaW9uLWlucHV0LWlvcyB7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbn1cblxuLmljb24ge1xuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgwZGVnLCByZ2JhKDM0LDE5MywxOTUsMSkgMCUsIHJnYmEoMCwxMDYsMjU1LDEpIDEwMCUpO1xuICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIG1hcmdpbi1ib3R0b206IDMwcHg7XG59XG5cbnAuQWJvdXQge1xuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgwZGVnLCByZ2JhKDM0LDE5MywxOTUsMSkgMCUsIHJnYmEoMCwxMDYsMjU1LDEpIDEwMCUpO1xuICAgIG1hcmdpbi1ib3R0b206IDFweDtcbiAgICBwYWRkaW5nOiAxMXB4O1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBmb250LWZhbWlseTogR290aGFtO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG5cblxuIl19 */"

/***/ }),

/***/ "./src/app/register/register.page.ts":
/*!*******************************************!*\
  !*** ./src/app/register/register.page.ts ***!
  \*******************************************/
/*! exports provided: RegisterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPage", function() { return RegisterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");








var RegisterPage = /** @class */ (function () {
    function RegisterPage(api, loadingController, formBuilder, router, http, toastController, alertController) {
        this.api = api;
        this.loadingController = loadingController;
        this.formBuilder = formBuilder;
        this.router = router;
        this.http = http;
        this.toastController = toastController;
        this.alertController = alertController;
        this.submitted = false;
        this.showErro = false;
        this.loggedIn = false;
        this.unMatchedCredentials = false;
        if (localStorage.getItem('LoggedInUser_data') != null) {
            this.router.navigate(['MyTab']);
        }
        if (localStorage.getItem('LoggedInUser_data') === null) {
            console.log('done');
        }
        this.registerForm = this.formBuilder.group({
            'FirstName': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            'MiddleName': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"]],
            'LastName': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            'DOB': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            'Address': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            'Nationality': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            'email': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            'password': [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(2)]],
        });
    }
    //  front-back ID no with Issue, Expiry With OCR
    RegisterPage.prototype.ngOnInit = function () {
    };
    RegisterPage.prototype.RegisterFun = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading, data, toast, toast;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        console.log(this.registerForm.value);
                        this.unMatchedCredentials = false;
                        this.submitted = true;
                        this.showErro = false;
                        return [4 /*yield*/, this.loadingController.create()];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        data = {
                            name: this.registerForm.value.FirstName + ' ' + this.registerForm.value.LastName,
                            email: this.registerForm.value.email,
                            password: this.registerForm.value.password,
                            type: '1',
                        };
                        console.log(data);
                        return [4 /*yield*/, this.api.RegisterApi(data)
                                .subscribe(function (res) {
                                console.log(res);
                                if (res.status === 0) {
                                    loading.dismiss();
                                    _this.unMatchedCredentials = true;
                                }
                                else if (res.status === 1) {
                                    _this.loggedIn = true;
                                    loading.dismiss();
                                    localStorage.removeItem('LoggedInUser_KYC');
                                    console.log('before == SAVING registerForm.value' + _this.registerForm.value);
                                    localStorage.setItem('LoggedInUser_KYC', _this.registerForm.value);
                                    _this.Login();
                                }
                            }, function (err) {
                                console.log(err);
                                loading.dismiss();
                                localStorage.removeItem('LoggedInUser_KYC');
                                console.log('before == SAVING registerForm.value' + JSON.stringify(_this.registerForm.value));
                                localStorage.setItem('LoggedInUser_KYC', JSON.stringify(_this.registerForm.value));
                                _this.router.navigate(['home']);
                            })];
                    case 3:
                        _a.sent();
                        if (!(this.loggedIn = true)) return [3 /*break*/, 6];
                        return [4 /*yield*/, this.toastController.create({
                                message: 'SUCCESSFULLY LOGGIN IN',
                                duration: 2000,
                                position: 'top'
                            })];
                    case 4:
                        toast = _a.sent();
                        return [4 /*yield*/, toast.present()];
                    case 5:
                        _a.sent();
                        return [3 /*break*/, 9];
                    case 6: return [4 /*yield*/, this.toastController.create({
                            message: 'WRONG CREDENTIALS - SIGNUP NOW.',
                            duration: 2000,
                            position: 'top'
                        })];
                    case 7:
                        toast = _a.sent();
                        return [4 /*yield*/, toast.present()];
                    case 8:
                        _a.sent();
                        _a.label = 9;
                    case 9: return [2 /*return*/];
                }
            });
        });
    };
    RegisterPage.prototype.Login = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading, data;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingController.create()];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        data = {
                            email: this.registerForm.value.email,
                            password: this.registerForm.value.password,
                        };
                        console.log(data);
                        return [4 /*yield*/, this.api.LoginApi(data)
                                .subscribe(function (res) {
                                console.log(res);
                                console.log(res);
                                _this.submitted = true;
                                _this.login_info_store = {
                                    name: JSON.stringify(res.name),
                                    id: JSON.stringify(res.id),
                                    auth_token: JSON.stringify(res.auth_token),
                                    type: JSON.stringify(res.type),
                                    email: _this.registerForm.value.email
                                };
                                localStorage.removeItem('LoggedInUser_data');
                                console.log('before' + _this.login_info_store);
                                localStorage.setItem('LoggedInUser_data', JSON.stringify(_this.login_info_store));
                                loading.dismiss();
                                _this.router.navigate(['MyTab']);
                            }, function (err) {
                                console.log(err);
                                loading.dismiss();
                            })];
                    case 3:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    RegisterPage.prototype.Back = function () {
        this.router.navigate(['LandingPage']);
    };
    RegisterPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-register',
            template: __webpack_require__(/*! ./register.page.html */ "./src/app/register/register.page.html"),
            styles: [__webpack_require__(/*! ./register.page.scss */ "./src/app/register/register.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_api_service__WEBPACK_IMPORTED_MODULE_6__["RestApiService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]])
    ], RegisterPage);
    return RegisterPage;
}());



/***/ })

}]);
//# sourceMappingURL=register-register-module.js.map